﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proj_casa_dos_dados
{
    public class CnpjDataContainer
    {
        public bool success { get; set; }
        public CnpjDataResponse data { get; set; }
    }
}
