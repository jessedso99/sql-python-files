﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proj_casa_dos_dados
{
    public class CnpjDataAtividadePrincipal
    {
        public string codigo { get; set; }
        public string descricao { get; set; }
    }
}
